<?php include('header.php'); ?>

	<!-- this is for welcome -->
	<div class="content">
		<article>
			<img src="img/welcome1.png" alt="welcome msg"> <h2 style="color:blue">Online Blood Management System</h2>
			<p class="text-justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt et dolores neque eaque. Labore, dicta similique ipsam odit saepe obcaecati suscipit ducimus, commodi dolores animi sed beatae, quia nulla facilis.lorem 
				Lorem ipsum dolor sit amet, consectetur adipisicing elit. Totam, doloribus quisquam eaque inventore consectetur sapiente itaque aliquid quae tempore. Eveniet iusto obcaecati magni qui laboriosam saepe unde, totam odio excepturi
				
			</p>
		</article>


	
	</div><br>

	<!-- nivo slider starts -->
	<div class="col-md-12 sliderImg">
		<img src="img/pic4.jpg" alt="">
		<img src="img/dash2.jpg" alt="">
		<img src="img/pic3.jpg" alt="">
		<img src="img/hstu5.jpg" alt="">
		
	</div>
	<!-- nivo slider ends -->

	<!-- main Content -->
	<div class="main_content">
		<div class="col-md-8">
			<article>
				<h3 style="font-weight: bold;font-family:inherit;">Why will you be Blood Donor/Seeker...?</h3> <hr>
				<p class="text-justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt et dolores neque eaque. Labore, dicta similique ipsam odit saepe obcaecati suscipit ducimus, commodi dolores animi sed beatae, quia nulla facilis.lorem 
				Lorem ipsum dolor sit amet, consectetur adipisicing elit. Totam, doloribus quisquam eaque inventore consectetur sapiente itaque aliquid quae tempore. Eveniet iusto obcaecati magni qui laboriosam saepe unde, totam odio excepturi
				Lorem ipsum dolor sit amet, consectetur adipisicing elit. Totam, doloribus quisquam eaque inventore consectetur sapiente itaque aliquid quae tempore. Eveniet iusto obcaecati magni qui laboriosam saepe unde, totam odio excepturi.</p>
			</article>
		</div>
		<div class="col-md-4">
			<h3 class="text-center" style="font-weight: bold;font-family:inherit;">Features!</h3><hr>
			<ul class="text-justify">
				
				Totam, doloribus quisquam eaque inventore consectetur sapiente itaque aliquid quae tempore. Eveniet iusto obcaecati magni qui laboriosam saepe unde, totam odio excepturi.  Eveniet iusto obcaecati magni qui laboriosam saepe unde, totam odio excepturi
			</ul>
		</div>

          
    </div>

 	<?php include('footer.php'); ?>


	
</div><!--  containerFluid Ends -->



	<script src="js/jquery-1.9.0.min.js"></script>
	<script src="js/bootstrap.min.js"></script>

	
	
</body>
</html>