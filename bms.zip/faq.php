<?php include('header.php'); ?>

<!-- <?php include('Admin/function.php'); ?>
 -->


	<!-- this is for donor registraton -->
	<div class="contactus"  style="background-color:#fff;">
		<h3 class="text-center" style="background-color:#272327;color: #fff;">Frequently Asked Question</h3>

		
		
		<div class="col-md-12 main_content" style="margin:15px; ">
			<div class="col-md-6" style="border-right: 2px solid black;">
				<h4>Q. What is Blood Mangement System?</h4>
				<details>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus ducimus, voluptatibus repudiandae nobis, dolores ipsa. Sit quaerat, eum explicabo, deleniti temporibus eos quam expedita magnam quis iure similique. Consectetur, qui!</details>

				<h4>Q. How can be I blood Donor or Seeker?</h4>
				<details>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus ducimus, voluptatibus repudiandae nobis, dolores ipsa. Sit quaerat, eum explicabo, deleniti temporibus eos quam expedita magnam quis iure similique. Consectetur, qui!</details>

				<h4>Q. Have I to charge to get blood Donor or Seeker?</h4>
				<details>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus ducimus, voluptatibus repudiandae nobis, dolores ipsa. Sit quaerat, eum explicabo, deleniti temporibus eos quam expedita magnam quis iure similique. Consectetur, qui!</details>

				<h4>Q. Have I to charge to get blood?</h4>
				<details>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus ducimus, voluptatibus repudiandae nobis, dolores ipsa. Sit quaerat, eum explicabo, deleniti temporibus eos quam expedita magnam quis iure similique. Consectetur, qui!</details>
			</div> 
			<div class="col-md-6">
				<h4>Q. Why will I be a blood Donor?</h4>
				<details>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus ducimus, voluptatibus repudiandae nobis, dolores ipsa. Sit quaerat, eum explicabo, deleniti temporibus eos quam expedita magnam quis iure similique. Consectetur, qui!</details>

				<h4>Q. Where can I donate blood?</h4>
				<details>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus ducimus, voluptatibus repudiandae nobis, dolores ipsa. Sit quaerat, eum explicabo, deleniti temporibus eos quam expedita magnam quis iure similique. Consectetur, qui!</details>

				<h4>Q. How many times can I donate blood in a year?</h4>
				<details>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus ducimus, voluptatibus repudiandae nobis, dolores ipsa. Sit quaerat, eum explicabo, deleniti temporibus eos quam expedita magnam quis iure similique. Consectetur, qui!</details>

				<h4>Q. How to find blood donor or seeker?</h4>
				<details>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus ducimus, voluptatibus repudiandae nobis, dolores ipsa. Sit quaerat, eum explicabo, deleniti temporibus eos quam expedita magnam quis iure similique. Consectetur, qui!</details>
			</div> 
		</div><br>

          
 	

	</div>
	
	

	
 	<?php include('footer.php'); ?>


	
	</div><!--  containerFluid Ends -->




	<script src="js/bootstrap.min.js"></script>




	
</body>
</html>

