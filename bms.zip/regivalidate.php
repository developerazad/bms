<?php
		if(isset($_POST["sbmt"])) {
			// $target_dir = "doner_pic/";
			// $target_file = $target_dir . basename($_FILES["t8"]["name"]);
			// $uploadOk = 1;
			// $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
		// 	// Check if image file is a actual image or fake image

		// 	    $check = getimagesize($_FILES["t8"]["tmp_name"]);
		// 	    if($check !== false) {
		// 	      //  echo "File is an image - " . $check["mime"] . ".";
		// 	        $uploadOk = 1;
		// 	    } else {
		// 	        echo "File is not an image.";
		// 	        $uploadOk = 0;
		// 	    }

		// 	// Check if file already exists
		// 	if (file_exists($target_file)) {
		// 	    echo "Sorry, file already exists.";
		// 	    $uploadOk = 0;
		// 	}
		// 	//aloow certain file formats
		// 	if($imageFileType != "jpg" && $imageFileType !="png" && $imageFileType !="jpeg" && $imageFileType !="gif"){
		// 			echo "sorry, only jpg, jpeg, Png & gif files are allowed.";
		// 			$uploadok=0;
		// 	}else{
		// 			if(move_uploaded_file($_FILES["t8"]["tmp_name"], $target_file)){
								$cn=makeconnection();
								// $s="INSERT INTO donarregistration(name,gender,age,mobile,b_id,email,pwd) VALUES('" . $_POST["t1"] ."','" . $_POST["r1"] . "','" . $_POST["t2"] . "','" . $_POST["t3"] . "','" . $_POST["t4"] . "','" . $_POST["t5"] . "','" . $_POST["t6"] .  "','" . basename($_FILES["t8"]["name"])  ."')";

								$s="INSERT INTO donarregistration(name,gender,age,mobile,address,b_id,email,pwd) VALUES('" . $_POST["t1"] ."','" . $_POST["r1"] . "','" . $_POST["t2"] . "','" . $_POST["t3"] . "','". $_POST["s3"] . "','" . $_POST["t4"] . "','" . $_POST["t5"] . "','" . $_POST["t6"] ."' )";
									
									//$s="INSERT INTO donarregistration(name,gender,age,mobile,b_id,email,pswd,pic) VALUES ([value-1],[value-2],[value-3],[value-4],[value-5],[value-6],[value-7],[value-8],[value-9])"
									mysqli_query($cn,$s);
									mysqli_close($cn);
									
									if($s>0){
									echo "<script>alert('Record has been saved!')</script>";
									}
									else{
										echo "<script>alert('Record  saved!')</script>";
									}
			// 			} else{
			// 				echo "sorry there was an error uploading your file.";
			// 			}	
				
			// 	}
			 }
?> 