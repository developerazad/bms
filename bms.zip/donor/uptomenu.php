<div class="container">
		<div class="header_top">
			<a href="../index.php"><img src="img/dash3.jpg" alt="logo.png img"></a>
			<span style="font-size:50px;color:#2c2f84;font-weight: bolder;margin-left: 15px;font-family: monospace;">
			 Donate Blood....Save Life!</span>
			
		</div>

	<!-- 	this is for menu -->
	<div class="navbar navbar-default nav">
		<nav class="menu">
			<ul>
				<li><a href="myDetails.php">Update Profile</a></li>
				<li><a href="search.php">Search</a></li>
				<li><a href="search2.php">Search Blood</a></li>
				<li><a href="history.php">Save Donation</a></li>
				<li><a href="viewdonation.php">View Donations</a></li>
				<li><a href="changePassword.php">Change Password</a></li>
				<li><a href="logout.php">Log Out</a></li>
			</ul>
		</nav>
	</div>