   <!-- footer section --> 
			<footer>
				<div class="col-md-12 fsection">
					<div class="col-md-4" id="contact">
					<p>Category</p>
					<ul>
						<li><a href="#">SignUp as a Donor</a></li>
						<li><a href="#">Contact with Doctors</a></li>
						
					</ul>
					</div>
					<div class="col-md-4">
						<p>Contact</p>
						<p>Md. Azharul Islam <br>
							BSc in ECE, HSTU, Dinajpur,</p>
						
							<span style="color: red;font-size: 15px">&copy;<?php echo date('Y'); ?>-All Rights Reserved</span>
					</div>
					<div class="col-md-4 share_img">
					<p>Share our website</p>
						<a href="http://www.facebook.com/sharer.php?u=http://developerazad.wordpress.com" target="_blank"><img src="img/fb-free.png" alt=""></a>
						<a href="https://plus.google.com/share?url=http://developerazad.wordpress.com" target="_blank"><img src="img/gogle-plud-free.png" alt=""></a>
						<a href="http://twitter.com/share?url=http://developerazad.wordpress.com" target="_blank"><img src="img/twitter.png" alt=""></a>
						
					</div>
				</div>
				

			</footer>

		<!-- footer section Ends--> 
