<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>blood management system</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="style.css">
	<script src="js/script.js"></script>
	<style>
		.error {color: #FF0000;}
	</style>
</head>
<body>
	<div class="container">
		<div class="header_top">
			<a href="index.php"><img src="img/dash3.jpg" alt="logo.png img"></a>

			<span style="font-size:60px;color:#2c2f84;font-weight: bolder;margin-left: 15px;font-family:inherit">
			 Donate Blood....Save Life...</span>
		</div>

		<!-- 	this is for menu -->
		<div class="navbar navbar-default nav">
			<nav class="menu">
				<ul>
					<li><a href="index.php">Home</a></li>
					<!-- <li style="float: right;border-right:0px solid;border-left:1px solid"><a href="signin.php">Login/SignUp</a></li> -->
					<li style="float: right;border-right:0px solid;border-left:1px solid"><a href="dslogin.php">Login/SignUp</a></li>
					<li><a href="faq.php">FAQ</a></li>
				</ul>
			</nav>
		</div>
		
